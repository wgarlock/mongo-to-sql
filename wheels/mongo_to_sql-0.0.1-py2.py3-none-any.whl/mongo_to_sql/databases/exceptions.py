class InconsistentMongoDBData(Exception):
    pass


class DataDictionaryMalformed(Exception):
    pass
