from mongo_to_sql.process.main import main

__all__ = [
    "main"
]
