from mongo_to_sql_tests.fixtures.create_env_vars import create_env_vars

create_env_vars()
